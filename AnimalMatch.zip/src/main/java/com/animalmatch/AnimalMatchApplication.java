package com.animalmatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnimalMatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnimalMatchApplication.class, args);
	}

}
