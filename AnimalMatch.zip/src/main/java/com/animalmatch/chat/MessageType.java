package com.animalmatch.chat;

public enum MessageType {
    CHAT,
    JOIN,
    LEAVE
}